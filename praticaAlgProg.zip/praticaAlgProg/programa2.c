/*
Fa�a outro programa, agora para listar um arquivo com estas estruturas.
*/

#include <stdio.h>
#include <string.h>

typedef struct{
       char nome[31];
       int idade;
       float altura;
}ATLETA;

int main(){
    ATLETA a;
    FILE *arq;
    char nome[16];

    printf("Nome do arquivo: \n");
    fgets(nome, 15, stdin);
    nome[strlen(nome)-1]= '\0';
    fflush(stdin);

    arq = fopen(nome, "rb"); // abre

    if(arq == NULL){
        printf("Erro na abertura\n");
    } else {
        printf("\n----- Comeco da Listagem -----\n\n");

        while(!feof(arq)){
            if(fread(&a, sizeof(ATLETA), 1, arq) == 1){
                printf("Nome: %s\n", a.nome);
                printf("Idade: %d\n", a.idade);
                printf("Altura: %.2f\n", a.altura);
                printf("\n");
            }
        }
        printf("----- Fim da Listagem -----\n");
        fclose(arq);
    }

    return 0;
}
