#include <stdio.h>
#include <string.h>

typedef struct
{
    char nome[10];
    int pontos;
} JOGADOR;

int main()
{
    JOGADOR a;
    FILE *arq; // ponteiro para arquivo

    arq = fopen("top_scores.bin", "rb"); // abre / leitura

    if(arq == NULL){
        printf("Erro na abertura\n");
    } else {
        printf("\n----- Comeco da Listagem -----\n\n");

        while(!feof(arq)){
            if(fread(&a, sizeof(JOGADOR), 1, arq) == 1){
                printf("Nome: %s\n", a.nome);
                printf("Pontos: %d\n", a.pontos);
                printf("\n");
            }
        }
        printf("----- Fim da Listagem -----\n");
        fclose(arq);
    }

    return 0;
}
