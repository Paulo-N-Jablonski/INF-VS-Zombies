/*
Fa�a outro programa que insere um novo registro no final do arquivo.
*/

#include <stdio.h>
#include <string.h>

typedef struct{
       char nome[31];
       int idade;
       float altura;
}ATLETA;

int main(){
    ATLETA a;
    FILE *arq;
    char nome[16];
    int op;

    printf("Nome do arquivo: \n");
    fgets(nome, 15, stdin);
    nome[strlen(nome)-1]= '\0';
    fflush(stdin);

    arq = fopen(nome, "ab"); // abre para acrescentar dados

    if(arq == NULL){
        printf("Erro na abertura\n");
    } else {

        do{
            printf("\nNome: ");
            fgets(a.nome, 30, stdin);
            a.nome[strlen(a.nome)-1] = '\0';

            printf("\nIdade: ");
            scanf("%d", &a.idade);

            printf("\nAltura: ");
            scanf("%f", &a.altura);

            if(fwrite(&a, sizeof(ATLETA), 1, arq) != 1){
                printf("Erro na grava��o");
            }

            printf("\n1- InserirNovo\n2- Encerrar\n");
            scanf("%i", &op);

            fflush(stdin);

        } while(op != 2);

        fclose(arq);
    }

    return 0;
}
