#include <stdio.h>
#include <string.h>

typedef struct
{
    char nome[10];
    int pontos;
} JOGADOR;

int main()
{
    JOGADOR a;
    FILE *arq;

    arq = fopen("top_scores.bin", "ab"); // abre / incremento

    if(arq == NULL)
    {
        printf("Erro na abertura\n");
    }
    else
    {

        printf("\nNome: ");
        fgets(a.nome, 9, stdin);
        a.nome[strlen(a.nome)-1] = '\0';

        fflush(stdin);

        printf("\Pontos: ");
        scanf("%d", &a.pontos);

        if(fwrite(&a, sizeof(JOGADOR), 1, arq) != 1)
        {
            printf("Erro na grava��o");
        }

        fclose(arq);
    }

    return 0;
}
