#include <stdio.h>

int main(){

    int a;
    FILE *fp;

    if(fread(&a, sizeof(a),1,fp) != 1){
        printf("Erro na leitura!\n");
    } else {
        fwrite(&a, 4, 1, fp);
    }
}
