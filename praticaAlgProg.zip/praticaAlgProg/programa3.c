/*
Fa�a um terceiro programa, para imprimir a altura de um determinado atleta, cujo nome foi lido do teclado.
*/

#include <stdio.h>
#include <string.h>

typedef struct
{
    char nome[31];
    int idade;
    float altura;
} ATLETA;

void procurarAtleta(FILE *pontoFlutuante, char procurado[]){
    ATLETA a;
    int encontrado = 0;

    rewind(pontoFlutuante);

    while(!feof(pontoFlutuante) && !encontrado){
        if(fread(&a, sizeof(ATLETA), 1, pontoFlutuante) == 1)

        if(!(strcmp(a.nome, procurado))){
            printf("\nAltura de %s: %.2fm", procurado, a.altura);
            encontrado = 1;
        }
    }

    if(!encontrado){
        printf("Atleta nao encontrado!\n\n");
    }
}

int main()
{
    ATLETA a;
    FILE *arq;
    char nome[16];
    char procurado[31];
    int op;

    printf("Nome do arquivo: \n");
    fgets(nome, 15, stdin);
    nome[strlen(nome)-1]= '\0';
    fflush(stdin);

    arq = fopen(nome, "rb"); // abre

    if(arq == NULL)
    {
        printf("Erro na abertura\n");
    }
    else
    {
        do
        {
            printf("Qual o nome do atleta?\n");
            fgets(procurado, 30, stdin);
            procurado[strlen(procurado)-1]= '\0';

            procurarAtleta(arq, procurado);

            printf("\n1- BuscarOutro\n2- Encerrar\n");
            scanf("%i", &op);

            fflush(stdin);

        } while(op != 2);

        fclose(arq);
    }


    return 0;
}
