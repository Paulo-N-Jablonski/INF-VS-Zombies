#include <stdio.h>
#include <string.h>

#define MAX 5

typedef struct
{
    char nome[10];
    int pontos;
} JOGADOR;

void ordenarPorPontos(JOGADOR v[], int tamanho)
{
    for (int i = 0; i < tamanho - 1; i++)
    {
        for (int j = 0; j < tamanho - i - 1; j++)
        {
            if (v[j].pontos < v[j + 1].pontos)
            {
                JOGADOR aux = v[j];
                v[j] = v[j + 1];
                v[j + 1] = aux;
            }
        }
    }
}

int main()
{
    JOGADOR *jogadores = NULL;
    int numJogadores = 0;
    FILE *arq;

    arq = fopen("top_scores.bin", "rb");

    if (arq == NULL)
    {
        printf("Erro ao abrir o arquivo para leitura\n");
    }
    else
    {

        // Mover o ponteiro do arquivo para o final para obter o tamanho do arquivo
        fseek(arq, 0, SEEK_END);
        long tamanhoArquivo = ftell(arq);  // Retorna o n�mero de bytes do arquivo
        rewind(arq);

        // Calcular o n�mero de jogadores no arquivo
        numJogadores = tamanhoArquivo / sizeof(JOGADOR);

        // Alocar mem�ria para armazenar todos os jogadores
        jogadores = (JOGADOR *)malloc(tamanhoArquivo);

        if (jogadores == NULL)
        {
            printf("Erro ao alocar mem�ria!\n");
        }
        else
        {

            // Ler todos os jogadores do arquivo
            fread(jogadores, sizeof(JOGADOR), numJogadores, arq);

            fclose(arq);
        }
    }

    ordenarPorPontos(jogadores, numJogadores);

    for (int i = 0; i < (numJogadores < MAX ? numJogadores : MAX); i++)
    {
        printf("Nome: %s\n", jogadores[i].nome);
        printf("Pontos: %d\n\n", jogadores[i].pontos);
    }

    // Liberar a mem�ria alocada
    free(jogadores);

    return 0;
}
